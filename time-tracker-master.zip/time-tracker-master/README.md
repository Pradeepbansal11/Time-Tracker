# time-tracker
Java (Maven) application for tracking time on the job

## Purpose

This purpose of this project is to show how to use Maven and Jenkins together.

Updates, 

and more updates
